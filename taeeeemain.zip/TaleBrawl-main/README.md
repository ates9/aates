![](screenshots/talebrawl.jpg)

# Tale Brawl V29
Brawl Stars v29 offline private server based on Royale Brawl written in C#.

# Features
- Almost all packets are coded
- Server is fully compatible with Discord Bot
- Creator system
- Online game rooms
- Clubs

# Requirements
dotnet 6.0 and mysql